# SetTalk Android Studio Project

This is an Android Studio-ready WebView wrapper for SetTalk.

## Build APK
1. Open this folder in Android Studio.
2. Let Gradle sync/download dependencies.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated debug APK on your Android phone.

## IMPORTANT: voice server
The APK is the mobile client. Voice signaling still needs the SetTalk Node.js server from the original project.
Start/deploy the Node.js server and, inside the app, enter its HTTPS URL in the Server box.

For a real internet deployment, use HTTPS/WSS and a TURN server for reliable WebRTC connections.
