
let ws, myId, room, localStream;
const peers = new Map();
const people = new Map();
let speaking = false;
const $ = id => document.getElementById(id);

function log(s) {
  const d = document.createElement("div");
  d.className = "log";
  d.textContent = s;
  $("activity").prepend(d);
}
function signal(x) {
  if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(x));
}
function wsUrl() {
  const base = window.SETTALK_SERVER_URL || "";
  if (!base) return (location.protocol === "https:" ? "wss://" : "ws://") + location.host;
  return base.replace(/^http:/, "ws:").replace(/^https:/, "wss:").replace(/\\/$/, "");
}
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c =>
    ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
}
function renderPeople(list) {
  $("people").innerHTML = "";
  list.forEach(p => people.set(p.id, p));
  list.forEach(p => {
    const d = document.createElement("div");
    d.className = "person";
    d.dataset.id = p.id;
    d.innerHTML = `<span>${escapeHtml(p.name)} <span class="status">${p.muted ? "MIC OFF" : "MIC ON"}</span></span><span class="role">${escapeHtml(p.role)}</span>`;
    $("people").appendChild(d);
  });
}
async function ensureMic() {
  if (!localStream) {
    localStream = await navigator.mediaDevices.getUserMedia({
      audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true},
      video:false
    });
    localStream.getAudioTracks()[0].enabled = false;
  }
}
async function createPeer(p, initiator) {
  let pc = peers.get(p.id);
  if (pc) return pc;
  pc = new RTCPeerConnection({
    iceServers:[{urls:"stun:stun.l.google.com:19302"}]
  });
  peers.set(p.id, pc);
  localStream.getTracks().forEach(t => pc.addTrack(t, localStream));
  pc.onicecandidate = e => {
    if (e.candidate) signal({type:"ice",to:p.id,candidate:e.candidate});
  };
  pc.ontrack = e => {
    let a = document.getElementById("a-"+p.id);
    if (!a) {
      a = document.createElement("audio");
      a.id = "a-"+p.id;
      a.autoplay = true;
      document.body.appendChild(a);
    }
    a.srcObject = e.streams[0];
  };
  pc.onconnectionstatechange = () => {
    if (["failed","closed","disconnected"].includes(pc.connectionState)) {
      peers.delete(p.id);
    }
  };
  if (initiator) {
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    signal({type:"offer",to:p.id,offer:pc.localDescription});
  }
  return pc;
}
async function handle(m) {
  if (m.type === "joined") {
    myId = m.id;
    renderPeople(m.roster);
    $("roomPanel").hidden = false;
    $("joinPanel").hidden = true;
    $("roomLabel").textContent = "ROOM: " + room;
    $("conn").textContent = "Connected";
    await ensureMic();
    for (const p of m.peers) await createPeer(p, true);
    log("You joined the room.");
    return;
  }
  if (m.type === "roster") { renderPeople(m.roster); return; }
  if (m.type === "user-joined") {
    people.set(m.user.id, m.user);
    log(`${m.user.name} joined`);
    return;
  }
  if (m.type === "user-left") {
    log(`${m.name || "A user"} left`);
    const pc = peers.get(m.id);
    if (pc) pc.close();
    peers.delete(m.id);
    const a = document.getElementById("a-"+m.id);
    if (a) a.remove();
    return;
  }
  if (m.type === "peer-mute") {
    log(`${m.name} ${m.muted ? "muted" : "unmuted"} their mic`);
    return;
  }
  if (m.type === "ptt") {
    log(`${m.fromName} is ${m.active ? "TALKING" : "done talking"}`);
    return;
  }
  if (m.type === "offer") {
    const p = {id:m.from,name:m.fromName || "Crew",role:"Crew"};
    const pc = await createPeer(p, false);
    await pc.setRemoteDescription(m.offer);
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    signal({type:"answer",to:m.from,answer:pc.localDescription});
    return;
  }
  if (m.type === "answer") {
    const pc = peers.get(m.from);
    if (pc) await pc.setRemoteDescription(m.answer);
    return;
  }
  if (m.type === "ice") {
    try { await peers.get(m.from)?.addIceCandidate(m.candidate); } catch {}
  }
}
$("join").onclick = async () => {
  const n = $("name").value.trim();
  const r = $("room").value.trim();
  if (!n || !r) {
    $("joinMsg").textContent = "Name and room code are required.";
    return;
  }
  try { await ensureMic(); }
  catch {
    $("joinMsg").textContent = "Microphone permission is required.";
    return;
  }
  room = r;
  ws = new WebSocket(wsUrl());
  ws.onopen = () => signal({type:"join",room,name:n,role:$("role").value});
  ws.onmessage = e => handle(JSON.parse(e.data));
  ws.onclose = () => {
    $("conn").textContent = "Disconnected";
    log("Connection closed.");
  };
  ws.onerror = () => {
    $("joinMsg").textContent = "Could not connect to server.";
  };
};
$("mic").onclick = async () => {
  await ensureMic();
  const track = localStream.getAudioTracks()[0];
  track.enabled = !track.enabled;
  $("mic").textContent = track.enabled ? "MIC ON" : "MIC OFF";
  signal({type:"mute",muted:!track.enabled});
};
function pttStart(e) {
  e.preventDefault();
  if (!localStream || speaking) return;
  speaking = true;
  const track = localStream.getAudioTracks()[0];
  track.enabled = true;
  $("mic").textContent = "MIC ON";
  $("ptt").classList.add("active");
  $("ptt").innerHTML = "TALKING…";
  $("talkState").textContent = "You are talking";
  signal({type:"ptt",active:true});
}
function pttEnd(e) {
  e.preventDefault();
  if (!localStream || !speaking) return;
  speaking = false;
  const track = localStream.getAudioTracks()[0];
  track.enabled = false;
  $("mic").textContent = "MIC OFF";
  $("ptt").classList.remove("active");
  $("ptt").innerHTML = "PRESS & HOLD<br>TO TALK";
  $("talkState").textContent = "Ready";
  signal({type:"ptt",active:false});
  signal({type:"mute",muted:true});
}
$("ptt").addEventListener("pointerdown", pttStart);
["pointerup","pointercancel","pointerleave"].forEach(x =>
  $("ptt").addEventListener(x, pttEnd)
);
$("leave").onclick = () => location.reload();

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => navigator.serviceWorker.register("sw.js").catch(()=>{}));
}
